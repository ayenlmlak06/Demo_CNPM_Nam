﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace QLBH
{
    public partial class frmCreateOrder : Form
    {
        public frmCreateOrder()
        {
            InitializeComponent();

            tbCreateOrder.ColumnCount = 8;
            tbCreateOrder.Columns[0].Name = "ID Exp";
            tbCreateOrder.Columns[1].Name = "Name";
            tbCreateOrder.Columns[2].Name = "Phone number";
            tbCreateOrder.Columns[3].Name = "Address";
            tbCreateOrder.Columns[4].Name = "Type Code";
            tbCreateOrder.Columns[5].Name = "Amount";
            tbCreateOrder.Columns[6].Name = "Total";
            tbCreateOrder.Columns[7].Name = "Buy date";
        }

        
        
        private void btn_OK_Click(object sender, EventArgs e)
        {
            if(tbCreateOrder.Rows.Count > 0)
            {
                SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=Data_QL;Integrated Security=True");
                for (int i = 0; i < tbCreateOrder.Rows.Count; i++)
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(@"INSERT INTO Customer (Phone, Cus_Name, Address) VALUES ('" + tbCreateOrder.Rows[i].Cells[2].Value + "', '" + tbCreateOrder.Rows[i].Cells[1].Value + "', '" + tbCreateOrder.Rows[i].Cells[3].Value + "')", con);
                    cmd.ExecuteNonQuery();
                    SqlCommand cm = new SqlCommand(@"INSERT INTO Export (IDExp, Phone, Buy_date, Total) VALUES ('" + tbCreateOrder.Rows[i].Cells[0].Value + "', '" + tbCreateOrder.Rows[i].Cells[2].Value + "', '" + tbCreateOrder.Rows[i].Cells[7].Value + "', '" + tbCreateOrder.Rows[i].Cells[6].Value + "')", con);
                    cm.ExecuteNonQuery();
                    SqlCommand md = new SqlCommand(@"INSERT INTO Information (Type_Code, Phone, Amount) VALUES ('" + tbCreateOrder.Rows[i].Cells[4].Value + "', '" + tbCreateOrder.Rows[i].Cells[2].Value + "', '" + tbCreateOrder.Rows[i].Cells[5].Value + "')", con);
                    md.ExecuteNonQuery();
                    con.Close();
                }

                MessageBox.Show("Order creation complete!");
                Microsoft.Office.Interop.Excel._Application excelApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = excelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "Export";                
                for(int i = 1; i < tbCreateOrder.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = tbCreateOrder.Columns[i - 1].HeaderText;
                }
                for(int i = 0; i < tbCreateOrder.Rows.Count; i++)
                {
                    for (int j = 0; j < tbCreateOrder.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = tbCreateOrder.Rows[i].Cells[j].Value.ToString();
                    }
                }
                var saveFileDialoge = new SaveFileDialog();
                saveFileDialoge.FileName = "Export";
                saveFileDialoge.DefaultExt = ".xlsx";
                if(saveFileDialoge.ShowDialog() == DialogResult.OK)
                {
                    workbook.SaveAs(saveFileDialoge.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                }
                excelApp.Quit();

                txtID.Text = "";
                txtName.Text = "";
                txtPhone.Text = "";
                txtAddress.Text = "";
                txtTypeCode.Text = "";
                txtAmountExp.Text = "";
                txtTotal.Text = "";

                tbCreateOrder.ClearSelection();
                txtID.Focus();
                btnDelete.Enabled = false;
                btnClear.Enabled = false;
                btn_OK.Enabled = false;
                btnAdd.Enabled = false;

                tbCreateOrder.Rows.Clear();
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            getData(txtID.Text, txtName.Text, txtPhone.Text, txtAddress.Text, txtTypeCode.Text, txtAmountExp.Text, txtTotal.Text, dateTimePicker.Text);

            txtID.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtTypeCode.Text = "";
            txtAmountExp.Text = "";
            txtTotal.Text = "";

            tbCreateOrder.ClearSelection();
            txtID.Focus();
            btnDelete.Enabled = false;
            btnClear.Enabled = false;
            btn_OK.Enabled = true;
            btnAdd.Enabled = false;
        }

        private void getData(string ID, string Name, string Phone, string Address, string TypeCode, string AmountExp, string Total, string dateTime)
        {
            String[] row = { ID, Name, Phone, Address, TypeCode, AmountExp, Total, dateTime };
            tbCreateOrder.Rows.Add(row);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int SelectedRows;
            SelectedRows = tbCreateOrder.CurrentCell.RowIndex;
            tbCreateOrder.Rows.RemoveAt(SelectedRows);

            btnDelete.Enabled = false;
            btnAdd.Enabled = true;
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
        }

        private void tbCreateOrder_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.tbCreateOrder.Rows[e.RowIndex];
            txtID.Text = row.Cells[0].Value.ToString();
            txtName.Text = row.Cells[1].Value.ToString();
            txtPhone.Text = row.Cells[2].Value.ToString();
            txtAddress.Text = row.Cells[3].Value.ToString();
            txtTypeCode.Text = row.Cells[4].Value.ToString();
            txtAmountExp.Text = row.Cells[5].Value.ToString();
            txtTotal.Text = row.Cells[6].Value.ToString();
            dateTimePicker.Text = row.Cells[7].Value.ToString();

            btnAdd.Enabled = false;
            btnDelete.Enabled = true;
            btnClear.Enabled = true;
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
        }

        private void txtTypeCode_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
        }

        private void txtAmountExp_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
        }

        private void txtTotal_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtTypeCode.Text = "";
            txtAmountExp.Text = "";
            txtTotal.Text = "";

            tbCreateOrder.ClearSelection();
            txtID.Focus();
            btnAdd.Enabled = false;
            btnDelete.Enabled = false;
            btnClear.Enabled = false;
            btn_OK.Enabled = true;
        }

        private void frmCreateOrder_Load(object sender, EventArgs e)
        {
            btnAdd.Enabled = false;
            btnClear.Enabled = false;
            btnDelete.Enabled = false;
            btn_OK.Enabled = false;
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtTypeCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtAmountExp_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
