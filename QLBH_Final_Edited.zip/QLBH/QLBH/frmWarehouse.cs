﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QLBH
{
    public partial class frmWarehouse : Form
    {
        public frmWarehouse()
        {
            InitializeComponent();
        }

        string connectionString = @"Data Source=.;Initial Catalog=Data_QL;Integrated Security=True";

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                DialogResult dr = MessageBox.Show("Are you sure", "Product delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    int selectedRow = this.tbWarehouse.CurrentCell.RowIndex;
                    tbWarehouse.Rows.RemoveAt(selectedRow);

                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM [Import] WHERE [Type_Code] = " + txtSelected.Text + "", con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Product has been deleted successfully");
                }
            }
            txtSelected.Text = "";
            btnDelete.Enabled = false;

            if (tbWarehouse.Rows.Count == 0)
            {
                txtSelected.ReadOnly = true;
            }
        }
        
        private void frmWarehouse_Load(object sender, EventArgs e)
        {
            btnDelete.Enabled = false;

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlCommand cmd = new SqlCommand(@"DELETE FROM [Warehouse] INSERT INTO [Warehouse] SELECT Type_Code, Name_Car, Price, SUM (Amount) AS Remaining FROM Import GROUP BY Type_Code, Name_Car, Price", sqlCon);
                cmd.ExecuteNonQuery();
                sqlCon.Close();
                SqlDataAdapter SqlDa = new SqlDataAdapter("SELECT * FROM Warehouse", sqlCon);
                DataTable dtbl = new DataTable();
                SqlDa.Fill(dtbl);
                foreach(DataRow item in dtbl.Rows)
                {
                    int n = tbWarehouse.Rows.Add();
                    tbWarehouse.Rows[n].Cells[0].Value = item["Type_Code"].ToString();
                    tbWarehouse.Rows[n].Cells[1].Value = item["Name_Car"].ToString();
                    tbWarehouse.Rows[n].Cells[2].Value = item["Price"].ToString();
                    tbWarehouse.Rows[n].Cells[3].Value = item["Remaining"].ToString();
                }
                //tbWarehouse.DataSource = dtbl;

                if(tbWarehouse.Rows.Count != 0)
                {
                    txtSelected.ReadOnly = false;
                }
            }
        }

        private void tbWarehouse_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtSelected.Text = tbWarehouse.CurrentRow.Cells[0].Value.ToString();
        }

        private void txtSelected_TextChanged(object sender, EventArgs e)
        {
            btnDelete.Enabled = true;
        }

        private void txtSelected_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
