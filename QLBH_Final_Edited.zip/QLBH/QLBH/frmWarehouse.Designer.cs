﻿
namespace QLBH
{
    partial class frmWarehouse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDelete = new System.Windows.Forms.Button();
            this.tbWarehouse = new System.Windows.Forms.DataGridView();
            this.typeCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameCar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remaining = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSelected = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.tbWarehouse)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(359, 5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 33);
            this.btnDelete.TabIndex = 16;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // tbWarehouse
            // 
            this.tbWarehouse.AllowUserToAddRows = false;
            this.tbWarehouse.AllowUserToDeleteRows = false;
            this.tbWarehouse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbWarehouse.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tbWarehouse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbWarehouse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.typeCode,
            this.nameCar,
            this.price,
            this.remaining});
            this.tbWarehouse.Location = new System.Drawing.Point(-1, 44);
            this.tbWarehouse.Name = "tbWarehouse";
            this.tbWarehouse.ReadOnly = true;
            this.tbWarehouse.Size = new System.Drawing.Size(448, 400);
            this.tbWarehouse.TabIndex = 19;
            this.tbWarehouse.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tbWarehouse_CellContentClick);
            // 
            // typeCode
            // 
            this.typeCode.HeaderText = "Type code";
            this.typeCode.Name = "typeCode";
            this.typeCode.ReadOnly = true;
            // 
            // nameCar
            // 
            this.nameCar.HeaderText = "Name";
            this.nameCar.Name = "nameCar";
            this.nameCar.ReadOnly = true;
            // 
            // price
            // 
            this.price.HeaderText = "Price";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            // 
            // remaining
            // 
            this.remaining.HeaderText = "Remaining";
            this.remaining.Name = "remaining";
            this.remaining.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "Selected";
            // 
            // txtSelected
            // 
            this.txtSelected.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSelected.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.txtSelected.Location = new System.Drawing.Point(86, 9);
            this.txtSelected.Name = "txtSelected";
            this.txtSelected.ReadOnly = true;
            this.txtSelected.Size = new System.Drawing.Size(166, 26);
            this.txtSelected.TabIndex = 1;
            this.txtSelected.TextChanged += new System.EventHandler(this.txtSelected_TextChanged);
            this.txtSelected.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSelected_KeyPress);
            // 
            // frmWarehouse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 444);
            this.Controls.Add(this.txtSelected);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbWarehouse);
            this.Controls.Add(this.btnDelete);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmWarehouse";
            this.Text = "Stock";
            this.Load += new System.EventHandler(this.frmWarehouse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tbWarehouse)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridView tbWarehouse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSelected;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameCar;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn remaining;
    }
}