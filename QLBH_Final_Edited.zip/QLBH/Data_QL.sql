CREATE DATABASE Data_QL
GO

USE [Data_QL]
GO

CREATE TABLE [Warehouse](
    [Type_Code] INT NOT NULL PRIMARY KEY,
    [Name_Car] NVARCHAR (50) NULL,
	[Price] BIGINT NULL,
    [Remaining] INT NULL    
)
GO

CREATE TABLE [Import](
    [IDImp] NVARCHAR(50) NOT NULL PRIMARY KEY,
    [Name_Car] NVARCHAR(50) NOT NULL,
    [Type_Code] INT NOT NULL,
    [Amount] INT NOT NULL,
    [Price] BIGINT NOT NULL,
    [Import_date] NVARCHAR(10)
)
GO

CREATE TABLE [Customer](
    [Phone] NVARCHAR (50) NOT NULL PRIMARY KEY,
    [Cus_Name] NVARCHAR (50) NOT NULL,
    [Address] NVARCHAR (100) NOT NULL
)
GO

CREATE TABLE [Export](
    [IDExp] NVARCHAR (50) NOT NULL PRIMARY KEY,
    [Phone] NVARCHAR (50) NOT NULL,
    [Buy_date] NVARCHAR(10),
    [Total] BIGINT NOT NULL,
    CONSTRAINT fk_PhoneEx FOREIGN KEY(Phone) REFERENCES Customer(Phone)
)
GO

CREATE TABLE [Information](
    [Type_Code] INT NOT NULL,
    [Phone] NVARCHAR (50) NOT NULL,
    [Amount] INT NOT NULL,
    CONSTRAINT fk_PhoneInfor FOREIGN KEY(Phone) REFERENCES Customer(Phone)
)
GO